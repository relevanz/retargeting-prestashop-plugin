<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{relevanz}prestashop>relevanz_0d10dccba07e24c861bb6e4e18c2bbbf'] = 'releva.nz - Technologie pour un marketing personnalisé';
$_MODULE['<{relevanz}prestashop>relevanz_537b6dfb53582d98fd06c2ff9e3f2f0e'] = 'Impossible de supprimer la structure du menu releva.nz.';
$_MODULE['<{relevanz}prestashop>relevanz_1e6ffda1e33f2b8a4edebec50566c7be'] = 'Impossible d\'enregistrer le titre du menu releva.nz.';
$_MODULE['<{relevanz}prestashop>relevanz_be1c09cea733ef0756a1ea0d3ba85e08'] = 'Impossible d\'enregistrer le sous-menu %s de releva.nz.';
$_MODULE['<{relevanz}prestashop>relevanz_9166bd30a168b9c89a8b002d9a62b5d0'] = 'La structure de menu du plugin releva.nz n\'a pas pu être installée.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_6231b94ff3fb7cca275feeef0ec2bf75'] = 'La clé API fournie n\'est pas valide. Veuillez fournir une clé API correcte.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_d090da4a2419540476fff62159fa21bb'] = 'La connexion au serveur API ne peut pas être établie. Veuillez réessayer plus tard.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_9749199409ed74942fea0f97aed18b58'] = 'La clé API ne peut pas être vérifiée. Veuillez vous assurer que la clé API est correcte.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_e7b0872bb358695e9f1d473849a45b0d'] = 'La clé API ne peut pas être vérifiée. Veuillez vous assurer que la clé API est correcte.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_558b49eb972c3c62a1a4e5b6d91420ae'] = 'Configuration sauvegardée.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_7a6c14e10f0670f5215b49b31c6d0443'] = 'Une ou plusieurs clés API sont utilisées par différentes instances multiboutiques. Cela peut entraîner un comportement indésirable. Veuillez vous assurer que chaque boutique utilise sa propre clé API. Si vous avez besoin de clés API supplémentaires, veuillez contacter le support releva.nz.';
$_MODULE['<{relevanz}prestashop>adminrelevanzstatscontroller_c33e404a441c6ba9648f88af3c68a1ca'] = 'Statistique';
$_MODULE['<{relevanz}prestashop>adminbasecontroller_3331e78f651d3451c222f533a9e9abb6'] = 'Le plugin releva.nz ne peut être configuré que pour des boutiques spécifiques. Veuillez changer le contexte d\'une boutique en particulier. Actuellement, la boutique [%s] est utilisée.';
$_MODULE['<{relevanz}prestashop>configuration_2b3433dd650bb461a55cbc0dd52d2f7c'] = 'Votre clé API releva.nz';
$_MODULE['<{relevanz}prestashop>configuration_6c06a335e72dfb88d79c5d123f761d1d'] = 'Si vous êtes déjà enregistré et avez reçu notre clé, veuillez l\'entrer dans ce champ.';
$_MODULE['<{relevanz}prestashop>configuration_005fb40c085e5a4ad3d0a6e183dafbcf'] = 'Vous n\'êtes pas encore inscrit? Attrapez-le maintenant!';
$_MODULE['<{relevanz}prestashop>configuration_98bbe02b1bc66f5988cd9e997ea80e3b'] = 'Votre identifiant client';
$_MODULE['<{relevanz}prestashop>configuration_37954eab7f99faa02e5a92460843804f'] = 'Exportation-URL';
$_MODULE['<{relevanz}prestashop>configuration_ae2bddad7ff3e00b6cc26534d1e796c0'] = 'Veuillez envoyer cette URL au service clientèle de releva.nz.';
