<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{relevanz}prestashop>relevanz_0d10dccba07e24c861bb6e4e18c2bbbf'] = 'releva.nz - Technologie für personalisiertes Marketing';
$_MODULE['<{relevanz}prestashop>relevanz_537b6dfb53582d98fd06c2ff9e3f2f0e'] = 'Die relevan.nz Menüstruktur konnte nicht entfernt werden.';
$_MODULE['<{relevanz}prestashop>relevanz_1e6ffda1e33f2b8a4edebec50566c7be'] = 'Die relevan.nz Menüüberschrift konnte nicht registriert werden.';
$_MODULE['<{relevanz}prestashop>relevanz_be1c09cea733ef0756a1ea0d3ba85e08'] = 'Das relevan.nz Untermenü %s konnte nicht registriert werden.';
$_MODULE['<{relevanz}prestashop>relevanz_9166bd30a168b9c89a8b002d9a62b5d0'] = 'Die Menüstruktur des relevan.nz-Plugins konnte nicht installiert werden.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_254f642527b45bc260048e30704edb39'] = 'Konfiguration';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_6231b94ff3fb7cca275feeef0ec2bf75'] = 'Der angegebene API-Key ist ungültig. Bitte geben Sie einen korrekten API-Key an.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_d090da4a2419540476fff62159fa21bb'] = 'Es kann keine Verbindung zum API-Server hergestellt werden. Bitte versuchen Sie es zu einem späteren Zeitpunkt erneut.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_9749199409ed74942fea0f97aed18b58'] = 'Der API-Key kann nicht überprüft werden. Bitte stellen Sie sicher, dass der API-Key korrekt ist.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_e7b0872bb358695e9f1d473849a45b0d'] = 'Der API-Key kann nicht überprüft werden. Bitte stellen Sie sicher, dass der API-Key korrekt ist.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_558b49eb972c3c62a1a4e5b6d91420ae'] = 'Einstellungen gespeichert.';
$_MODULE['<{relevanz}prestashop>adminrelevanzconfcontroller_7a6c14e10f0670f5215b49b31c6d0443'] = 'Einer oder mehrere API-Keys werden von verschiedenen Multistore-Instanzen genutzt. Dies kann zu ungewolltem Verhalten führen. Bitte stellen Sie sicher, dass jeder Shop einen eigenen API-Key verwendet. Wenn Sie weitere API-Keys benötigen, kontaktieren Sie bitte den releva.nz Support.';
$_MODULE['<{relevanz}prestashop>adminrelevanzstatscontroller_c33e404a441c6ba9648f88af3c68a1ca'] = 'Statistik';
$_MODULE['<{relevanz}prestashop>adminbasecontroller_3331e78f651d3451c222f533a9e9abb6'] = 'Das releva.nz Plugin kann nur für spezifische Shops konfiguriert werden. Bitte wechseln Sie den Kontext auf einen spezifischen Shop. Aktuell wird der Shop [%s] verwendet.';
$_MODULE['<{relevanz}prestashop>configuration_2b3433dd650bb461a55cbc0dd52d2f7c'] = 'Ihr releva.nz API Key';
$_MODULE['<{relevanz}prestashop>configuration_6c06a335e72dfb88d79c5d123f761d1d'] = 'Wenn sie bereits registriert sind und unseren Key erhalten haben, geben Sie diesen bitte in diesem Feld ein.';
$_MODULE['<{relevanz}prestashop>configuration_005fb40c085e5a4ad3d0a6e183dafbcf'] = 'Noch nicht registriert? Jetzt nachholen!';
$_MODULE['<{relevanz}prestashop>configuration_98bbe02b1bc66f5988cd9e997ea80e3b'] = 'Ihre Kunden ID';
$_MODULE['<{relevanz}prestashop>configuration_37954eab7f99faa02e5a92460843804f'] = 'Export-URL';
$_MODULE['<{relevanz}prestashop>configuration_ae2bddad7ff3e00b6cc26534d1e796c0'] = 'Bitte übermitteln Sie diese URL an den releva.nz Kundenservice.';
